# Mini Hospital Emergency Management System

## CIT300 – Data Structures and Algorithms

This project implements a Mini Hospital Emergency Management System in Java.

### Data Structures

1. **Binary Search Tree (BST)**
   - Stores patient records using Patient ID.
   - Insert, search, delete and in-order traversal.

2. **Queue**
   - Manages emergency patients.
   - Uses FIFO (First-In, First-Out).

3. **Stack**
   - Stores completed treatment records.
   - Uses LIFO (Last-In, First-Out).

4. **Singly Linked List**
   - Stores each patient's previous hospital visits.
   - Add, search, remove and display operations.

### Patient Information

- Patient ID
- Patient Name
- Age
- Contact Number
- Medical Condition

### Visit Information

- Visit ID
- Visit Date
- Doctor Name
- Diagnosis
- Treatment

## Requirements

- Java JDK 17 or later

## Run

From the `src` directory:

```bash
javac *.java
java Main
```

## Project Structure

```text
MiniHospitalEmergencySystem/
├── src/
│   ├── Main.java
│   ├── Patient.java
│   ├── PatientBST.java
│   ├── EmergencyQueue.java
│   ├── TreatmentStack.java
│   ├── Visit.java
│   └── VisitLinkedList.java
├── sample_test_data.txt
└── README.md
```

## Sample Testing

See `sample_test_data.txt` for suggested test cases.

## Academic Note

This project is a reference implementation for study and development. Before submission, the student should understand, test, and adapt the implementation as appropriate for their own individual assignment.
