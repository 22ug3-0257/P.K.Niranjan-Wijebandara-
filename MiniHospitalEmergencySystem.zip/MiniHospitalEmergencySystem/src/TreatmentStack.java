public class TreatmentStack {
    private class StackNode {
        String treatmentRecord;
        StackNode next;
        StackNode(String treatmentRecord) { this.treatmentRecord = treatmentRecord; }
    }

    private StackNode top;

    public void push(String treatmentRecord) {
        StackNode newNode = new StackNode(treatmentRecord);
        newNode.next = top;
        top = newNode;
    }

    public String pop() {
        if (top == null) {
            System.out.println("Treatment history is empty.");
            return null;
        }
        String record = top.treatmentRecord;
        top = top.next;
        return record;
    }

    public void display() {
        if (top == null) {
            System.out.println("No treatment records found.");
            return;
        }

        StackNode current = top;
        System.out.println("\nTreatment History:");
        while (current != null) {
            System.out.println(current.treatmentRecord);
            current = current.next;
        }
    }

    public boolean isEmpty() { return top == null; }
}
