public class EmergencyQueue {
    private class QueueNode {
        Patient patient;
        QueueNode next;
        QueueNode(Patient patient) { this.patient = patient; }
    }

    private QueueNode front, rear;

    public void enqueue(Patient patient) {
        QueueNode newNode = new QueueNode(patient);
        if (rear == null) {
            front = rear = newNode;
            return;
        }
        rear.next = newNode;
        rear = newNode;
    }

    public Patient dequeue() {
        if (front == null) {
            System.out.println("Emergency queue is empty.");
            return null;
        }

        Patient patient = front.patient;
        front = front.next;
        if (front == null) rear = null;
        return patient;
    }

    public void display() {
        if (front == null) {
            System.out.println("No patients are waiting.");
            return;
        }

        QueueNode current = front;
        System.out.println("\nPatients Waiting for Treatment:");
        while (current != null) {
            System.out.println(current.patient);
            current = current.next;
        }
    }

    public boolean isEmpty() { return front == null; }
}
