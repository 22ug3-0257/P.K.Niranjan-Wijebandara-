public class PatientBST {
    private class Node {
        Patient patient;
        Node left, right;
        Node(Patient patient) { this.patient = patient; }
    }

    private Node root;

    public boolean insert(Patient patient) {
        if (search(patient.getPatientId()) != null) return false;
        root = insertRecursive(root, patient);
        return true;
    }

    private Node insertRecursive(Node current, Patient patient) {
        if (current == null) return new Node(patient);

        if (patient.getPatientId() < current.patient.getPatientId())
            current.left = insertRecursive(current.left, patient);
        else if (patient.getPatientId() > current.patient.getPatientId())
            current.right = insertRecursive(current.right, patient);

        return current;
    }

    public Patient search(int patientId) {
        Node result = searchRecursive(root, patientId);
        return result == null ? null : result.patient;
    }

    private Node searchRecursive(Node current, int patientId) {
        if (current == null) return null;
        if (patientId == current.patient.getPatientId()) return current;
        if (patientId < current.patient.getPatientId())
            return searchRecursive(current.left, patientId);
        return searchRecursive(current.right, patientId);
    }

    public boolean delete(int patientId) {
        if (search(patientId) == null) return false;
        root = deleteRecursive(root, patientId);
        return true;
    }

    private Node deleteRecursive(Node current, int patientId) {
        if (current == null) return null;

        if (patientId < current.patient.getPatientId()) {
            current.left = deleteRecursive(current.left, patientId);
        } else if (patientId > current.patient.getPatientId()) {
            current.right = deleteRecursive(current.right, patientId);
        } else {
            if (current.left == null && current.right == null) return null;
            if (current.left == null) return current.right;
            if (current.right == null) return current.left;

            Node successor = findMinimum(current.right);
            current.patient = successor.patient;
            current.right = deleteRecursive(
                    current.right, successor.patient.getPatientId());
        }
        return current;
    }

    private Node findMinimum(Node current) {
        while (current.left != null) current = current.left;
        return current;
    }

    public void displayInOrder() {
        if (root == null) {
            System.out.println("No patient records found.");
            return;
        }
        inOrder(root);
    }

    private void inOrder(Node current) {
        if (current != null) {
            inOrder(current.left);
            System.out.println(current.patient);
            inOrder(current.right);
        }
    }
}
