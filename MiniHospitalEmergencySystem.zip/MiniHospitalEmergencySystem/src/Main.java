import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final PatientBST patientBST = new PatientBST();
    private static final EmergencyQueue emergencyQueue = new EmergencyQueue();
    private static final TreatmentStack treatmentStack = new TreatmentStack();

    public static void main(String[] args) {
        int choice;

        do {
            displayMenu();
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> registerPatient();
                case 2 -> searchPatient();
                case 3 -> deletePatient();
                case 4 -> patientBST.displayInOrder();
                case 5 -> addEmergencyPatient();
                case 6 -> treatNextPatient();
                case 7 -> emergencyQueue.display();
                case 8 -> addTreatmentRecord();
                case 9 -> removeTreatmentRecord();
                case 10 -> treatmentStack.display();
                case 11 -> addVisit();
                case 12 -> searchVisit();
                case 13 -> removeVisit();
                case 14 -> displayVisitHistory();
                case 0 -> System.out.println("Thank you for using the Hospital Management System.");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 0);

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\n====================================");
        System.out.println(" MINI HOSPITAL EMERGENCY SYSTEM");
        System.out.println("====================================");
        System.out.println("1. Register Patient");
        System.out.println("2. Search Patient");
        System.out.println("3. Delete Patient");
        System.out.println("4. Display Patients - In Order");
        System.out.println("5. Add Patient to Emergency Queue");
        System.out.println("6. Treat Next Patient");
        System.out.println("7. Display Emergency Queue");
        System.out.println("8. Add Treatment Record");
        System.out.println("9. Remove Latest Treatment");
        System.out.println("10. Display Treatment History");
        System.out.println("11. Add Patient Visit");
        System.out.println("12. Search Patient Visit");
        System.out.println("13. Remove Patient Visit");
        System.out.println("14. Display Patient Visit History");
        System.out.println("0. Exit");
        System.out.println("====================================");
    }

    private static void registerPatient() {
        System.out.println("\n--- Register Patient ---");
        int id = readInt("Patient ID: ");
        String name = readString("Patient Name: ");
        int age = readInt("Age: ");
        String contact = readString("Contact Number: ");
        String condition = readString("Medical Condition: ");

        Patient patient = new Patient(id, name, age, contact, condition);

        if (patientBST.insert(patient))
            System.out.println("Patient registered successfully.");
        else
            System.out.println("Patient ID already exists.");
    }

    private static void searchPatient() {
        int id = readInt("Enter Patient ID to search: ");
        Patient patient = patientBST.search(id);

        if (patient != null) {
            System.out.println("\nPatient Found:");
            System.out.println(patient);
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void deletePatient() {
        int id = readInt("Enter Patient ID to delete: ");
        if (patientBST.delete(id))
            System.out.println("Patient deleted successfully.");
        else
            System.out.println("Patient not found.");
    }

    private static void addEmergencyPatient() {
        int id = readInt("Enter Patient ID to add to emergency queue: ");
        Patient patient = patientBST.search(id);

        if (patient == null) {
            System.out.println("Patient does not exist.");
            return;
        }

        emergencyQueue.enqueue(patient);
        System.out.println("Patient added to emergency queue.");
    }

    private static void treatNextPatient() {
        Patient patient = emergencyQueue.dequeue();
        if (patient != null) {
            System.out.println("\nNow treating:");
            System.out.println(patient);
        }
    }

    private static void addTreatmentRecord() {
        int patientId = readInt("Patient ID: ");
        Patient patient = patientBST.search(patientId);

        if (patient == null) {
            System.out.println("Patient not found.");
            return;
        }

        String treatment = readString("Enter treatment completed: ");
        String record = "Patient ID: " + patientId +
                " | Patient: " + patient.getPatientName() +
                " | Treatment: " + treatment;

        treatmentStack.push(record);
        System.out.println("Treatment record added successfully.");
    }

    private static void removeTreatmentRecord() {
        String record = treatmentStack.pop();
        if (record != null) {
            System.out.println("Removed treatment record:");
            System.out.println(record);
        }
    }

    private static Patient getPatientForVisit() {
        int patientId = readInt("Patient ID: ");
        Patient patient = patientBST.search(patientId);

        if (patient == null) System.out.println("Patient not found.");
        return patient;
    }

    private static void addVisit() {
        System.out.println("\n--- Add Patient Visit ---");
        Patient patient = getPatientForVisit();
        if (patient == null) return;

        int visitId = readInt("Visit ID: ");
        String date = readString("Visit Date: ");
        String doctor = readString("Doctor Name: ");
        String diagnosis = readString("Diagnosis: ");
        String treatment = readString("Treatment: ");

        patient.getVisitHistory().addVisit(
                new Visit(visitId, date, doctor, diagnosis, treatment));

        System.out.println("Visit added successfully.");
    }

    private static void searchVisit() {
        Patient patient = getPatientForVisit();
        if (patient == null) return;

        int visitId = readInt("Visit ID to search: ");
        Visit visit = patient.getVisitHistory().searchVisit(visitId);

        if (visit != null) {
            System.out.println("\nVisit Found:");
            System.out.println(visit);
        } else {
            System.out.println("Visit not found.");
        }
    }

    private static void removeVisit() {
        Patient patient = getPatientForVisit();
        if (patient == null) return;

        int visitId = readInt("Visit ID to remove: ");
        boolean removed = patient.getVisitHistory().removeVisit(visitId);

        System.out.println(removed
                ? "Visit removed successfully."
                : "Visit not found.");
    }

    private static void displayVisitHistory() {
        Patient patient = getPatientForVisit();
        if (patient != null) patient.getVisitHistory().displayHistory();
    }

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static String readString(String message) {
        System.out.print(message);
        return scanner.nextLine().trim();
    }
}
